//
//  MovieRepository.swift
//  MoviesListSwiftUI
//
//  Created by Ani Mekvabidze on 3/6/24.
//

import Foundation

class MovieRepository {
    static let shared = MovieRepository()
    
    private let movies: [Movie] = [
        Movie(title: "Avatar", year: "2009", genre: "Action", description: "A paraplegic Marine dispatched to the moon Pandora on a unique mission becomes torn between following his orders and protecting the world he feels is his home."),
        Movie(title: "Dune", year: "2021", genre: "Sci-Fi", description: "Feature adaptation of Frank Herbert's science fiction novel, about the son of a noble family entrusted with the protection of the most valuable asset and most vital element in the galaxy."),
        Movie(title: "Interstellar", year: "2014", genre: "Sci-Fi", description: "A team of explorers travel through a wormhole in space in an attempt to ensure humanity's survival."),
        Movie(title: "The Matrix", year: "1999", genre: "Action", description: "A computer hacker learns from mysterious rebels about the true nature of his reality and his role in the war against its controllers."),
        Movie(title: "The Dark Knight", year: "2008", genre: "Action", description: "When the menace known as The Joker wreaks havoc and chaos on the people of Gotham, Batman must accept one of the greatest psychological and physical tests of his ability to fight injustice."),
        Movie(title: "Schindler's List", year: "1993", genre: "Biography", description: "In German-occupied Poland during World War II, industrialist Oskar Schindler gradually becomes concerned for his Jewish workforce after witnessing their persecution by the Nazis."),
        Movie(title: "Pulp Fiction", year: "1994", genre: "Crime", description: "The lives of two mob hitmen, a boxer, a gangster and his wife, and a pair of diner bandits intertwine in four tales of violence and redemption."),
        Movie(title: "Forrest Gump", year: "1994", genre: "Drama", description: "The presidencies of Kennedy and Johnson, the events of Vietnam, Watergate, and other historical events unfold from the perspective of an Alabama man with an IQ of 75, whose only desire is to be reunited with his childhood sweetheart."),
        Movie(title: "Inception", year: "2010", genre: "Sci-Fi", description: "A thief who enters the dreams of others to steal secrets."),
        Movie(title: "The Shawshank Redemption", year: "1994", genre: "Drama", description: "Two imprisoned men bond over a number of years, finding solace and eventual redemption through acts of common decency."),
        Movie(title: "The Godfather", year: "1972", genre: "Crime", description: "The aging patriarch of an organized crime dynasty transfers control of his clandestine empire to his reluctant son."),
        Movie(title: "The Lord of the Rings: The Fellowship of the Ring", year: "2001", genre: "Adventure", description: "A meek Hobbit from the Shire and eight companions set out on a journey to destroy the powerful One Ring and save Middle-earth from the Dark Lord Sauron."),
        Movie(title: "The Lord of the Rings: The Two Towers", year: "2002", genre: "Adventure", description: "While Frodo and Sam edge closer to Mordor with the help of the shifty Gollum, the divided fellowship makes a stand against Sauron's new ally, Saruman, and his hordes of Isengard."),
        Movie(title: "The Lord of the Rings: The Return of the King", year: "2003", genre: "Adventure", description: "Gandalf and Aragorn lead the World of Men against Sauron's army to draw his gaze from Frodo and Sam as they approach Mount Doom with the One Ring."),
    ]
    
    func getMovies() -> [Movie] {
        return movies
    }
}
