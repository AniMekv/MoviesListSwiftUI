//
//  MovieDetailView.swift
//  MoviesListSwiftUI
//
//  Created by Ani Mekvabidze on 3/6/24.
//

import SwiftUI

struct MovieDetailView: View {
    var movie: Movie
        
        var body: some View {
            VStack(alignment: .leading) {
                Text(movie.title)
                    .font(.title)
                Text("Year: \(movie.year)")
                    .font(.subheadline)
                Text("Genre: \(movie.genre)")
                    .font(.subheadline)
                Text(movie.description)
                    .padding(.top, 20)
            }
            .padding()
            .navigationTitle(movie.title)
        }
}

struct MovieDetailView_Previews: PreviewProvider {
    static var previews: some View {
        let sampleMovie = Movie(title: "Inception", year: "2010", genre: "Sci-Fi", description: "A thief who enters the dreams of others to steal secrets.")

        MovieDetailView(movie: sampleMovie)
    }
}
