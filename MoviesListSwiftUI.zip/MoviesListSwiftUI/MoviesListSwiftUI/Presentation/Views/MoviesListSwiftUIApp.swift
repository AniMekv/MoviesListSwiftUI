//
//  MoviesListSwiftUIApp.swift
//  MoviesListSwiftUI
//
//  Created by Ani Mekvabidze on 3/6/24.
//

import SwiftUI

@main
struct MoviesListSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            MovieListView()
        }
    }
}
