//
//  MovieListView.swift
//  MoviesListSwiftUI
//
//  Created by Ani Mekvabidze on 3/6/24.
//

import SwiftUI

struct MovieListView: View {
    @State var viewModel = MovieListViewModel()
    @State var coordinator = Coordinator()
       
       var body: some View {
           NavigationView {
               List(viewModel.movies) { movie in
                   Button(action: {
                       coordinator.showMovieDetail(movie: movie)
                   }) {
                       VStack(alignment: .leading) {
                           Text("Title: \(movie.title)")
                               .font(.headline)
                               .tint(.primary)
                           Text("Year: \(movie.year)")
                               .font(.subheadline)
                               .tint(.primary)
                       }
                   }
               }
               .navigationTitle("Movies")
               .sheet(item: $coordinator.selectedMovie) { movie in MovieDetailView(movie: movie)
               }
           }
       }
}

struct MovieListView_Previews: PreviewProvider {
    static var previews: some View {
        MovieListView()
    }
}
