//
//  MovieListViewModel.swift
//  MoviesListSwiftUI
//
//  Created by Ani Mekvabidze on 3/6/24.
//

import Foundation

@Observable
class MovieListViewModel: ObservableObject {
    var movies: [Movie] = []
    
    init() {
        fetchMovies()
    }
    
    func fetchMovies() {
        movies = MovieRepository.shared.getMovies()
    }
}
