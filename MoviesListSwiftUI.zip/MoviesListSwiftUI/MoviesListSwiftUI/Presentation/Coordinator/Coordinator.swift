//
//  Coordinator.swift
//  MoviesListSwiftUI
//
//  Created by Ani Mekvabidze on 3/6/24.
//

import Foundation

@Observable
class Coordinator {
    var selectedMovie: Movie? = nil
    
    func showMovieDetail(movie: Movie) {
        selectedMovie = movie
    }
}
