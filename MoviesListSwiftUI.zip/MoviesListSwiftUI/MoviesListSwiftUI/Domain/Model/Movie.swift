//
//  Movie.swift
//  MoviesListSwiftUI
//
//  Created by Ani Mekvabidze on 3/6/24.
//

import Foundation

struct Movie: Identifiable {
    var id = UUID()
    var title: String
    var year: String
    var genre: String
    var description: String
}
